#ifndef __INFO_H__
#define __INFO_H__

struct Info {
  int row, col;
  bool state;
};

#endif
